export const INITIALIZE = 'INITIALIZE';
export const AUTH_CHECK = 'AUTH_CHECK'
export const ADD_ISSUE =  'ADD_ISSUE';
export const VIEWS = 'VIEWS'
export const DELETE_ISSUE = 'DELETE_ISSUE'
export const USER_DATA = 'USER_DATA'